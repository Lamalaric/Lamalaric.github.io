----------------------------------------------------------
						Magic Maze
----------------------------------------------------------

Magic Maze est un jeu de plateau en python pour 1 à 3 joueurs,
s'inspirant du jeu de plateau Magic Maze déjà existant.

Le but est de faire sortir les 4 pions dans un temps imparti,
en récupérant les objets propres à chaque pions à l'aide de 
différentes actions.


---------
Pré-requis :
---------
- Python 3.7


---------
Installation :
---------
- Dézipper le dossier contenant les fichiers de jeu ainsi que toutes
  les images
- Les images doivent impérativement être dans le même dossier que le
  fichier "magicmaze.py"
- Exécuter le fichier "magicmaze.py" via l'invite de commande ou avec un IDE


---------
Outils de développement :
---------
- Sublime Text 3


---------
Updates :
---------
Phase 1 :
	Lancement du jeu : Dylan, Julian, Amalaric
	Déplacements : Dylan, Julian, Amalaric
	Objets / sortie : Amalaric
	Fin de partie : Amalaric
	Timer : Julian
	Debug : Dylan, Julian, Amalaric

Phase 2 :
	Escalator : Julian, Amalaric
	Vortex : Dylan, Amalaric
	2 joueurs : Amalaric
	Murs : Amalaric
	Cases sablier : Amalaric
	3 joueurs : Amalaric
	Menu du jeu : Amalaric

Phase 3 :
	Explorer : Amalaric


---------
Autre :
---------
Non implémenté :
	- Extension 1 :: Raison : ?
	- Extension 2 :: Raison : ?

Problèmes :
	- La tuile contenant la sortie à 2 escalators ne s'affichant pas
	- rare bug où lors de l'ajout d'une tuile vers le haut,
	  la tuile à sa droite se décale d'une case (ajout de None dans la matrice)
	- Le temps affiché lorsque l'on finit une partie n'est pas correct (problème de calcul)
	- Le jeu ralentit fortement au fur et à mesure (variables surchargées ?)
	- La partie "exploration" du programme est copiée collée 4 fois, besoin d'optimisation